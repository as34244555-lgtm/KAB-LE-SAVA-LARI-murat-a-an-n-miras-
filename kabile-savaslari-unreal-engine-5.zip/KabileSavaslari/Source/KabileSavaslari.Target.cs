using UnrealBuildTool;
using System.Collections.Generic;

public class KabileSavaslariTarget : TargetRules
{
    public KabileSavaslariTarget(TargetInfo Target) : base(Target)
    {
        Type = TargetType.Game;
        DefaultBuildSettings = BuildSettingsVersion.V5;
        IncludeOrderVersion = EngineIncludeOrderVersion.Unreal5_4;
        ExtraModuleNames.Add("KabileSavaslari");
    }
}
